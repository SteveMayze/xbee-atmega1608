# libavrxbee
A library for constructing and interpretting XBee Series 2 API frames
